Challenge 1B
I added all the other important computed values; Emax, a, b, and c.

Challenge 1C
I checked if the two objects have a roundness within 0.09 of each other.