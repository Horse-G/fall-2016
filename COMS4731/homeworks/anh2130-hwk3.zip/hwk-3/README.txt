1b)
I used the default voting scheme - increment by 1 for each recognized line.

1c)
If the value was greater than the threshold, I marked it as a peak.