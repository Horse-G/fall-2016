#!/bin/bash
PATH="~/coms3102bin: ${PATH}";
hello.coms3102;
