#!/bin/bash
echo "Hello World this machine is named ${HOSTNAME}";
